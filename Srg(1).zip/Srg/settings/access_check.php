<?php
session_start();
ob_start();
require_once('../config.php');

if(!isset($_SESSION['fallow'])) {
    header('HTTP/1.1 404 Not Found');
    exit();
}

$_SESSION['access_allow'] = true;

if($live_control['access_to'] == 'home'){
    $lnk = 'home.php';
 }else{
    $lnk = 'login.php';
 }

 header('location: '.$lnk);
 exit();
?>