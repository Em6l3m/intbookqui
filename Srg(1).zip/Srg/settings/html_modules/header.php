<?php if($html['header'] == true){ ?>
<header class="cloudos-toolbar login overlay">
    <div class="logo" style="margin-top:10px">
        <a href="javascript:void(0);" aria-label="">
        <img src="media/cloud.jpg" alt="">
        </a>
    </div>
</header>
<?php } ?>