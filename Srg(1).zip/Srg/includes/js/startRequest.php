<script>
$(document).ready(function() {
    setInterval(makeRequest, 2000);     
});
</script>