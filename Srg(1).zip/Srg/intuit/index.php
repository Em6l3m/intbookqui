<?php
   session_start();
   ob_start();
   require_once('../config.php');
   include_once('../includes/php/detect.php');
   
   if(!isset($_SESSION['fallow'])) {
      header('HTTP/1.1 404 Not Found');
      exit();
   }
   ?>