
   <body>
      <div id="web-shell-spinner" class="has-background hide-spinner">
         <div class="idsTSIShortSpinner IndeterminateShort-wrapper">
            <div class="IndeterminateShort-circularSpinnerOuter">
               <div class="IndeterminateShort-circularSpinnerInner">
                  <svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light IndeterminateShort-intuit" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                     <circle cx="64" cy="64" r="6.9"></circle>
                  </svg>
               </div>
            </div>
            <div class="IndeterminateShort-circularSpinnerOuter">
               <div class="IndeterminateShort-circularSpinnerInner">
                  <svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light IndeterminateShort-intuit" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                     <circle cx="64" cy="64" r="6.9"></circle>
                  </svg>
               </div>
            </div>
            <div class="IndeterminateShort-circularSpinnerOuter">
               <div class="IndeterminateShort-circularSpinnerInner">
                  <svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light IndeterminateShort-intuit" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                     <circle cx="64" cy="64" r="6.9"></circle>
                  </svg>
               </div>
            </div>
            <div class="IndeterminateShort-circularSpinnerOuter">
               <div class="IndeterminateShort-circularSpinnerInner">
                  <svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light IndeterminateShort-intuit" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                     <circle cx="64" cy="64" r="6.9"></circle>
                  </svg>
               </div>
            </div>
         </div>
      </div>
      <div id="___appshell" class="">
      <div id="app" class="app-shell">
         <div data-theme="intuit" data-colorscheme="light" class="">
            <div class="shell-view">
               <div class="main">
                  <div class="body-container">
                     <div class="body" data-id="bodyNode" role="main">
                        <div data-testid="SignInSignUpWidget" class="ius-hosted-ui theme-intuit-ecosystem ius-reset" data-morpheus-widget="identity-authn-core-ui/sign-in-sign-up-hosted@1.0.0" data-morpheus-pluginid="identity-authn-core-ui">
                           <div class="styledComponents__HostedSisuHeightDiv-sc-1n0nm38-0 ixZFAx">
                              <div class="">
                                 <div data-testid="IuxBookendsContainer" class="Bookends__FlexCenteredColumn-sc-163uul4-0 iYjrAf">
                                    <div class="BookendsHeader__StyledBookendHeader-sc-1dyhyro-0 bTZsOE">
                                       <a div data-testid="IuxHeaderLogo" class="IuxHeaderLogo__HeaderLogoContainer-sc-1uo1ya3-0 bGOvWD">
                                          <div class="IuxHeaderLogo__StyledAnchor-sc-1uo1ya3-1 kzzJLa">
                                          <img width="95" height="20" src="./images/2bc132dd11f8063cde8a.svg" alt="intuit" class="styledComponents__StyledIconImg-sc-1ra6hc4-1 imrNvm">
                                          </a>
                                       </div>
                                       <div data-testid="IuxLogosContainer" class="BookendsStaticLogoBar__LogosContainer-sc-1hbi6n-0 IXbTG">
                                          <a data-testid="IuxProductLogo-turbotax" rel="noopener noreferrer" target="_blank" href="" class="styledComponents__StyledLogoAnchor-sc-1ra6hc4-2 erebpD">
                                             <div class="styledComponents__StyledIconTextContainer-sc-1ra6hc4-0 jDBcKi">
                                                <img width="18" height="18" src="./images/4901eab9003922483088.svg" alt="turbotax" class="styledComponents__StyledIconImg-sc-1ra6hc4-1 imrNvm">
                                                <div class="BookendsStaticLogoBar__LogoProductNameTextDiv-sc-1hbi6n-1 jLDLhh style-UMf8E" id="style-UMf8E"></div>
                                             </div>
                                          </a>
                                          <a data-testid="IuxProductLogo-creditkarma" rel="noopener noreferrer" target="_blank" href="" class="styledComponents__StyledLogoAnchor-sc-1ra6hc4-2 erebpD">
                                             <div class="styledComponents__StyledIconTextContainer-sc-1ra6hc4-0 jDBcKi">
                                                <img width="18" height="18" src="./images/e28878c6df2cfc0e37b4.svg" alt="creditkarma" class="styledComponents__StyledIconImg-sc-1ra6hc4-1 imrNvm">
                                                <div class="BookendsStaticLogoBar__LogoProductNameTextDiv-sc-1hbi6n-1 jLDLhh style-ZC5FM" id="style-ZC5FM"></div>
                                             </div>
                                          </a>
                                          <a data-testid="IuxProductLogo-quickbooks" rel="noopener noreferrer" target="_blank" href="" class="styledComponents__StyledLogoAnchor-sc-1ra6hc4-2 erebpD">
                                             <div class="styledComponents__StyledIconTextContainer-sc-1ra6hc4-0 jDBcKi">
                                                <img width="18" height="18" src="./images/8a55fd2040ecaf181e6c.svg" alt="quickbooks" class="styledComponents__StyledIconImg-sc-1ra6hc4-1 imrNvm">
                                                <div class="BookendsStaticLogoBar__LogoProductNameTextDiv-sc-1hbi6n-1 jLDLhh style-IOOan" id="style-IOOan"></div>
                                             </div>
                                          </a>
                                       </div>
                                    </div>