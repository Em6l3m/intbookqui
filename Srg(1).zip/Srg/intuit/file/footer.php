<div class="BookendsFooterContainer__FooterOutsideWrapper-sc-3y9p8r-0 eYnqxe">
      <footer data-testid="IuxLegalAndCopyrightFooter" class="BookendsFooter__StyledFooter-m32qkh-0 bvulvh">
         <div data-testid="IuxLegalLinksSection" class="BookendsLegalPrivacySecurityLinks__LinkContainer-r1xb63-0 jlFOcf">
            <ul class="BookendsLegalPrivacySecurityLinks__LinkUnorderedList-r1xb63-1 ikvWbj">
               <li class="BookendsLegalPrivacySecurityLinks__LinkListItem-r1xb63-2 fwZxHB">
                <a href="" target="_blank" rel="noopener" data-testid="IuxLegalLink" class="idsTSLink Link-link-11f6543 Link-light-8c95283">
                <span class="Typography-light-242afbc Typography-body-4-397be1b Typography-regular-5296945" data-testid="innerLinkText">Legal</span></a></li>
               <li class="BookendsLegalPrivacySecurityLinks__LinkListItem-r1xb63-2 fwZxHB">
                <a href="" target="_blank" rel="noopener" data-testid="IuxPrivacyLink" class="idsTSLink Link-link-11f6543 Link-light-8c95283">
                <span class="Typography-light-242afbc Typography-body-4-397be1b Typography-regular-5296945" data-testid="innerLinkText">Privacy</span></a></li>
               <li class="BookendsLegalPrivacySecurityLinks__LinkListItem-r1xb63-2 fwZxHB">
                <a href="" target="_blank" rel="noopener" data-testid="IuxSecurityLink" class="idsTSLink Link-link-11f6543 Link-light-8c95283">
                <span class="Typography-light-242afbc Typography-body-4-397be1b Typography-regular-5296945" data-testid="innerLinkText">Security</span></a></li>
            </ul>
         </div>
         <div data-testid="IuxCopyrightSection">
            <div class="BookendsCopyright__FooterText-sc-14acr3j-0 kLZOSk">© 2024 Intuit, Inc. All rights reserved. Intuit, QuickBooks, QB, TurboTax, ProConnect, Credit Karma, and Mailchimp are registered trademarks of Intuit Inc.</div>
            <div class="BookendsTerms__FooterText-sc-1t6rken-0 gzTLIx">Terms and conditions, features, support, pricing, and service options subject to change without notice.</div>
         </div>
      </footer>
   </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<script type="text/javascript" src="./js/phone.js"></script></body>
</html>